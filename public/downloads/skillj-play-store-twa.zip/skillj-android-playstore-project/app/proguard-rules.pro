# TWA Proguard rules
-keepattributes *Annotation*
