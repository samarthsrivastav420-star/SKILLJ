# 🚀 Google Play Console Par SKILLJ App (.aab) Upload Karne Ka Poora Guide

Aapko Google Play Console par app daalne ke liye sabhi zaroori files ready karke de di gayi hain:
1. **skillj-release.aab**: Google Play Store upload bundle file.
2. **playstore-icon-512x512.png**: Play Store listing ke liye 512x512 high-resolution icon.
3. **assetlinks.json**: Google Play verification file jo website ke `/.well-known/assetlinks.json` par live hai.

---

### Step 1: Google Play Console Me Nayi App Banayein
1. [play.google.com/console](https://play.google.com/console) open karein.
2. **"Create app"** button par click karein.
3. App Details bharein:
   - **App name**: `SKILLJ — Online Education & Learning Platform`
   - **Default language**: English (India) ya Hindi
   - **App or Game**: App
   - **Free or Paid**: Free (Kyunki subscription payments app ke andar hoti hain)
   - Declarations accept karke **Create app** par click karein.

---

### Step 2: Store Listing (Graphics & Details)
1. Dashboard me **"Set up your store listing"** par jayein.
2. **Short description**: `India's most trusted online education platform for SKILL, COURSE, and EDUCATION.`
3. **Full description**: `Learn and grow with verified master instructors across programming, data science, and board education. Join live classes, take monthly 1st day exams, and earn verified UNIVERSE certificates.`
4. **App icon**: Folder me di gayi `playstore-icon-512x512.png` upload karein.
5. Screenshots: Apne phone se 2-3 screenshots lekar upload karein.

---

### Step 3: .AAB File Upload Karein
1. Left menu me **"Production"** (ya testing ke liye **"Internal testing"**) par click karein.
2. Top-right me **"Create new release"** par click karein.
3. **"App bundles"** section me **`skillj-release.aab`** file ko drag & drop ya upload karein.
4. Release name: `1.0.0 (Initial Official Release)`
5. **Next** par click karein aur review karke **"Save & Rollout"** karein!

---

### Step 4: Digital Asset Links (Full-Screen Verification)
Google Play Store jab aapki app ko install karega, to wo aapki website ke `/.well-known/assetlinks.json` ko verify karega taki Chrome address bar gayab ho sake.
Aapki website par ye file already live hai:
`https://your-domain.com/.well-known/assetlinks.json`

Agar Play Console me "App signing key certificate fingerprint" alag mile, to us SHA-256 fingerprint ko `public/.well-known/assetlinks.json` me update kar dein.

Badhai ho! Aapki SKILLJ app Google Play Store par publish hone ke liye 100% ready hai! 🎉
